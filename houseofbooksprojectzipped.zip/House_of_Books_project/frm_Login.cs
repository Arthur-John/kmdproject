﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace House_of_Books_project
{
    public partial class frm_Login : Form
    {
        public frm_Login()
        {
            InitializeComponent();
        }

        private void frm_Login_Load(object sender, EventArgs e)
        {
            ShowMenu("");
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (mnuLogin.Text == "Logout")
            {
                if (MessageBox.Show("Are you sure you want to Logout", "Confirm", MessageBoxButtons.YesNo)
                    == DialogResult.Yes)
                {
                    mnuLogin.Text = "Login";
                    ShowMenu("");
                }
                return;
            }
            clsMainDBobj_clsMainDB = new clsMainDB();
            frm_Loginobj_frmlogin = new frm_Login();
            DataTable DT = new DataTable();
            String UserName = "";
            String Password = "";

        Start:
            obj_frmLogin.txtUsername.Text = UserName;
            obj_frmLogin.txtPassword.Text = Password;
            if (obj_frmLogin.ShowDialog() == DialogResult.OK)
            {
                if (obj_frmLogin.txtUsername.Text.Trim().ToString() == string.Empty)
                {
                    MessageBox.Show("Please Type User Name.");
                    obj_frmLogin.txtUsername.Focus();
                    goto Start;
                }
                UserName = obj_frmLogin.txtUsername.Text;
                if (obj_frmLogin.txtPassword.Text.Trim().ToString() == string.Empty)
                {
                    MessageBox.Show("Please type Password.");
                    obj_frmLogin.txtPassword.Focus();
                    goto Start;
                }
                Password = obj_frmLogin.txtPassword.Text;
                stringSPString = string.Format("SP_Select_UserSetting N'{0}', N'{1}', N'{2}'",
                obj_frmLogin.txtUserName.Text.Trim().ToString(),obj_frmLogin,txtPassword.Text.Trim().ToString(),"1");

                DT = obj_clsMainDB.SelectData(SPString);
                if (DT.Rows.Count > 0)
                {
                    Program.UserID = Convert.ToInt32(DT.Rows[0]["UserID"].ToString());
                    string Userlevel = DT.Rows[0]["UserID"].ToString());
                    mnuLogin.Text = "Logout";
                    Show Menu(Userlevel);
                }
                else
                {
                    MessageBox.Show("Invalid UserName and Password");
                    goto Start;
                }
            }
        }
    }
}
