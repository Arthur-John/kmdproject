﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace House_of_Books_project
{
    public partial class frm_UserSetting : Form
    {
        public frm_UserSetting()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string userId = txtUserID.Text;
            string userName = txtUserName.Text;
            string password = txtPassword.Text;
            string updateDate = txtUpdateDate.Text;
            bool userLevel = chkUserLevel.Checked;

            
            try
            {
                
                string connectionString = "YourConnectionStringHere";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "INSERT INTO UserSettings (UserID, UserName, Password, UpdateDate, UserLevel) " +
                                   "VALUES (@UserID, @UserName, @Password, @UpdateDate, @UserLevel)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@UserID", userId);
                        command.Parameters.AddWithValue("@UserName", userName);
                        command.Parameters.AddWithValue("@Password", password);
                        command.Parameters.AddWithValue("@UpdateDate", updateDate);
                        command.Parameters.AddWithValue("@UserLevel", userLevel);

                        command.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("User settings saved successfully!");

                
                frm_SaleDetail saleDetailForm = new frm_SaleDetail();
                saleDetailForm.Show();
                this.Close(); 
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtUpdateDate_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
