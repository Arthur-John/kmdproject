﻿namespace House_of_Books_project
{
    partial class frm_Sale
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblSaleID = new System.Windows.Forms.Label();
            this.lblVoucher = new System.Windows.Forms.Label();
            this.lblSaleDate = new System.Windows.Forms.Label();
            this.lblTotalAmt = new System.Windows.Forms.Label();
            this.lblTax = new System.Windows.Forms.Label();
            this.lblDiscount = new System.Windows.Forms.Label();
            this.lblDelivery = new System.Windows.Forms.Label();
            this.lblGrandTotal = new System.Windows.Forms.Label();
            this.lblUserID = new System.Windows.Forms.Label();
            this.labelSaleID = new System.Windows.Forms.Label();
            this.labelVoucher = new System.Windows.Forms.Label();
            this.labelSaleDate = new System.Windows.Forms.Label();
            this.labelTotalAmount = new System.Windows.Forms.Label();
            this.labelTax = new System.Windows.Forms.Label();
            this.labelDiscount = new System.Windows.Forms.Label();
            this.labelDeli = new System.Windows.Forms.Label();
            this.labelGTotal = new System.Windows.Forms.Label();
            this.txtUserID = new System.Windows.Forms.Label();
            this.btnDone = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblSaleID
            // 
            this.lblSaleID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSaleID.Location = new System.Drawing.Point(164, 41);
            this.lblSaleID.Name = "lblSaleID";
            this.lblSaleID.Size = new System.Drawing.Size(100, 23);
            this.lblSaleID.TabIndex = 0;
            this.lblSaleID.Text = "Sale ID:";
            // 
            // lblVoucher
            // 
            this.lblVoucher.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblVoucher.Location = new System.Drawing.Point(164, 133);
            this.lblVoucher.Name = "lblVoucher";
            this.lblVoucher.Size = new System.Drawing.Size(100, 23);
            this.lblVoucher.TabIndex = 1;
            this.lblVoucher.Text = "Voucher:";
            // 
            // lblSaleDate
            // 
            this.lblSaleDate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSaleDate.Location = new System.Drawing.Point(164, 244);
            this.lblSaleDate.Name = "lblSaleDate";
            this.lblSaleDate.Size = new System.Drawing.Size(100, 23);
            this.lblSaleDate.TabIndex = 2;
            this.lblSaleDate.Text = "Sale Date:";
            // 
            // lblTotalAmt
            // 
            this.lblTotalAmt.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTotalAmt.Location = new System.Drawing.Point(164, 358);
            this.lblTotalAmt.Name = "lblTotalAmt";
            this.lblTotalAmt.Size = new System.Drawing.Size(100, 23);
            this.lblTotalAmt.TabIndex = 3;
            this.lblTotalAmt.Text = "Total Amount:";
            // 
            // lblTax
            // 
            this.lblTax.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTax.Location = new System.Drawing.Point(164, 472);
            this.lblTax.Name = "lblTax";
            this.lblTax.Size = new System.Drawing.Size(100, 23);
            this.lblTax.TabIndex = 4;
            this.lblTax.Text = "Tax:";
            // 
            // lblDiscount
            // 
            this.lblDiscount.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblDiscount.Location = new System.Drawing.Point(164, 582);
            this.lblDiscount.Name = "lblDiscount";
            this.lblDiscount.Size = new System.Drawing.Size(100, 23);
            this.lblDiscount.TabIndex = 5;
            this.lblDiscount.Text = "Discount:";
            // 
            // lblDelivery
            // 
            this.lblDelivery.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblDelivery.Location = new System.Drawing.Point(164, 705);
            this.lblDelivery.Name = "lblDelivery";
            this.lblDelivery.Size = new System.Drawing.Size(100, 23);
            this.lblDelivery.TabIndex = 6;
            this.lblDelivery.Text = "Delivery fees:";
            // 
            // lblGrandTotal
            // 
            this.lblGrandTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblGrandTotal.Location = new System.Drawing.Point(164, 810);
            this.lblGrandTotal.Name = "lblGrandTotal";
            this.lblGrandTotal.Size = new System.Drawing.Size(100, 23);
            this.lblGrandTotal.TabIndex = 7;
            this.lblGrandTotal.Text = "Grand Total:";
            // 
            // lblUserID
            // 
            this.lblUserID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblUserID.Location = new System.Drawing.Point(164, 905);
            this.lblUserID.Name = "lblUserID";
            this.lblUserID.Size = new System.Drawing.Size(100, 23);
            this.lblUserID.TabIndex = 8;
            this.lblUserID.Text = "User ID:";
            // 
            // labelSaleID
            // 
            this.labelSaleID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelSaleID.Location = new System.Drawing.Point(491, 41);
            this.labelSaleID.Name = "labelSaleID";
            this.labelSaleID.Size = new System.Drawing.Size(191, 23);
            this.labelSaleID.TabIndex = 9;
            // 
            // labelVoucher
            // 
            this.labelVoucher.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelVoucher.Location = new System.Drawing.Point(491, 133);
            this.labelVoucher.Name = "labelVoucher";
            this.labelVoucher.Size = new System.Drawing.Size(191, 23);
            this.labelVoucher.TabIndex = 10;
            // 
            // labelSaleDate
            // 
            this.labelSaleDate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelSaleDate.Location = new System.Drawing.Point(491, 244);
            this.labelSaleDate.Name = "labelSaleDate";
            this.labelSaleDate.Size = new System.Drawing.Size(191, 23);
            this.labelSaleDate.TabIndex = 11;
            // 
            // labelTotalAmount
            // 
            this.labelTotalAmount.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelTotalAmount.Location = new System.Drawing.Point(491, 358);
            this.labelTotalAmount.Name = "labelTotalAmount";
            this.labelTotalAmount.Size = new System.Drawing.Size(191, 23);
            this.labelTotalAmount.TabIndex = 12;
            // 
            // labelTax
            // 
            this.labelTax.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelTax.Location = new System.Drawing.Point(491, 472);
            this.labelTax.Name = "labelTax";
            this.labelTax.Size = new System.Drawing.Size(191, 23);
            this.labelTax.TabIndex = 13;
            // 
            // labelDiscount
            // 
            this.labelDiscount.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelDiscount.Location = new System.Drawing.Point(491, 582);
            this.labelDiscount.Name = "labelDiscount";
            this.labelDiscount.Size = new System.Drawing.Size(191, 23);
            this.labelDiscount.TabIndex = 14;
            // 
            // labelDeli
            // 
            this.labelDeli.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelDeli.Location = new System.Drawing.Point(491, 705);
            this.labelDeli.Name = "labelDeli";
            this.labelDeli.Size = new System.Drawing.Size(191, 23);
            this.labelDeli.TabIndex = 15;
            // 
            // labelGTotal
            // 
            this.labelGTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelGTotal.Location = new System.Drawing.Point(491, 810);
            this.labelGTotal.Name = "labelGTotal";
            this.labelGTotal.Size = new System.Drawing.Size(191, 23);
            this.labelGTotal.TabIndex = 16;
            // 
            // txtUserID
            // 
            this.txtUserID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txtUserID.Location = new System.Drawing.Point(491, 905);
            this.txtUserID.Name = "txtUserID";
            this.txtUserID.Size = new System.Drawing.Size(191, 23);
            this.txtUserID.TabIndex = 17;
            // 
            // btnDone
            // 
            this.btnDone.Location = new System.Drawing.Point(720, 978);
            this.btnDone.Name = "btnDone";
            this.btnDone.Size = new System.Drawing.Size(136, 47);
            this.btnDone.TabIndex = 18;
            this.btnDone.Text = "&Done";
            this.btnDone.UseVisualStyleBackColor = true;
            this.btnDone.Click += new System.EventHandler(this.btnDone_Click);
            // 
            // frm_Sale
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1013, 1055);
            this.Controls.Add(this.btnDone);
            this.Controls.Add(this.txtUserID);
            this.Controls.Add(this.labelGTotal);
            this.Controls.Add(this.labelDeli);
            this.Controls.Add(this.labelDiscount);
            this.Controls.Add(this.labelTax);
            this.Controls.Add(this.labelTotalAmount);
            this.Controls.Add(this.labelSaleDate);
            this.Controls.Add(this.labelVoucher);
            this.Controls.Add(this.labelSaleID);
            this.Controls.Add(this.lblUserID);
            this.Controls.Add(this.lblGrandTotal);
            this.Controls.Add(this.lblDelivery);
            this.Controls.Add(this.lblDiscount);
            this.Controls.Add(this.lblTax);
            this.Controls.Add(this.lblTotalAmt);
            this.Controls.Add(this.lblSaleDate);
            this.Controls.Add(this.lblVoucher);
            this.Controls.Add(this.lblSaleID);
            this.Name = "frm_Sale";
            this.Text = "frm_Sale";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblSaleID;
        private System.Windows.Forms.Label lblVoucher;
        private System.Windows.Forms.Label lblSaleDate;
        private System.Windows.Forms.Label lblTotalAmt;
        private System.Windows.Forms.Label lblTax;
        private System.Windows.Forms.Label lblDiscount;
        private System.Windows.Forms.Label lblDelivery;
        private System.Windows.Forms.Label lblGrandTotal;
        private System.Windows.Forms.Label lblUserID;
        private System.Windows.Forms.Label labelSaleID;
        private System.Windows.Forms.Label labelVoucher;
        private System.Windows.Forms.Label labelSaleDate;
        private System.Windows.Forms.Label labelTotalAmount;
        private System.Windows.Forms.Label labelTax;
        private System.Windows.Forms.Label labelDiscount;
        private System.Windows.Forms.Label labelDeli;
        private System.Windows.Forms.Label labelGTotal;
        private System.Windows.Forms.Label txtUserID;
        private System.Windows.Forms.Button btnDone;
    }
}