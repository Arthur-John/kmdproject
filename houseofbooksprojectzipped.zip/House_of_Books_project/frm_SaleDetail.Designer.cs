﻿namespace House_of_Books_project
{
    partial class frm_SaleDetail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblSaleID = new System.Windows.Forms.Label();
            this.lblBookID = new System.Windows.Forms.Label();
            this.lblSaleQ = new System.Windows.Forms.Label();
            this.lblSalePrice = new System.Windows.Forms.Label();
            this.labelSaleID = new System.Windows.Forms.Label();
            this.labelBookID = new System.Windows.Forms.Label();
            this.labelSaleQ = new System.Windows.Forms.Label();
            this.labelSalePrice = new System.Windows.Forms.Label();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblSaleID
            // 
            this.lblSaleID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSaleID.Location = new System.Drawing.Point(200, 36);
            this.lblSaleID.Name = "lblSaleID";
            this.lblSaleID.Size = new System.Drawing.Size(100, 28);
            this.lblSaleID.TabIndex = 0;
            this.lblSaleID.Text = "Sale ID";
            // 
            // lblBookID
            // 
            this.lblBookID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblBookID.Location = new System.Drawing.Point(200, 163);
            this.lblBookID.Name = "lblBookID";
            this.lblBookID.Size = new System.Drawing.Size(100, 28);
            this.lblBookID.TabIndex = 1;
            this.lblBookID.Text = "Book ID";
            // 
            // lblSaleQ
            // 
            this.lblSaleQ.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSaleQ.Location = new System.Drawing.Point(200, 281);
            this.lblSaleQ.Name = "lblSaleQ";
            this.lblSaleQ.Size = new System.Drawing.Size(100, 28);
            this.lblSaleQ.TabIndex = 2;
            this.lblSaleQ.Text = "Sale Quantity";
            // 
            // lblSalePrice
            // 
            this.lblSalePrice.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSalePrice.Location = new System.Drawing.Point(200, 407);
            this.lblSalePrice.Name = "lblSalePrice";
            this.lblSalePrice.Size = new System.Drawing.Size(100, 28);
            this.lblSalePrice.TabIndex = 3;
            this.lblSalePrice.Text = "Sale Price";
            // 
            // labelSaleID
            // 
            this.labelSaleID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelSaleID.Location = new System.Drawing.Point(491, 37);
            this.labelSaleID.Name = "labelSaleID";
            this.labelSaleID.Size = new System.Drawing.Size(229, 23);
            this.labelSaleID.TabIndex = 4;
            // 
            // labelBookID
            // 
            this.labelBookID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelBookID.Location = new System.Drawing.Point(491, 163);
            this.labelBookID.Name = "labelBookID";
            this.labelBookID.Size = new System.Drawing.Size(229, 23);
            this.labelBookID.TabIndex = 5;
            // 
            // labelSaleQ
            // 
            this.labelSaleQ.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelSaleQ.Location = new System.Drawing.Point(491, 281);
            this.labelSaleQ.Name = "labelSaleQ";
            this.labelSaleQ.Size = new System.Drawing.Size(229, 23);
            this.labelSaleQ.TabIndex = 6;
            // 
            // labelSalePrice
            // 
            this.labelSalePrice.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelSalePrice.Location = new System.Drawing.Point(491, 407);
            this.labelSalePrice.Name = "labelSalePrice";
            this.labelSalePrice.Size = new System.Drawing.Size(229, 23);
            this.labelSalePrice.TabIndex = 7;
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(341, 589);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(83, 33);
            this.btnNext.TabIndex = 8;
            this.btnNext.Text = "&Next";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(764, 589);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(85, 33);
            this.btnCancel.TabIndex = 9;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.button2_Click);
            // 
            // frm_SaleDetail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1096, 758);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.labelSalePrice);
            this.Controls.Add(this.labelSaleQ);
            this.Controls.Add(this.labelBookID);
            this.Controls.Add(this.labelSaleID);
            this.Controls.Add(this.lblSalePrice);
            this.Controls.Add(this.lblSaleQ);
            this.Controls.Add(this.lblBookID);
            this.Controls.Add(this.lblSaleID);
            this.Name = "frm_SaleDetail";
            this.Text = "SaleDetail";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblSaleID;
        private System.Windows.Forms.Label lblBookID;
        private System.Windows.Forms.Label lblSaleQ;
        private System.Windows.Forms.Label lblSalePrice;
        private System.Windows.Forms.Label labelSaleID;
        private System.Windows.Forms.Label labelBookID;
        private System.Windows.Forms.Label labelSaleQ;
        private System.Windows.Forms.Label labelSalePrice;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnCancel;
    }
}