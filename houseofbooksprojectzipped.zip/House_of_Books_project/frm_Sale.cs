﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace House_of_Books_project
{
    public partial class frm_Sale : Form
    {
        public frm_Sale()
        {
            InitializeComponent();
        }

        private void btnDone_Click(object sender, EventArgs e)
        {
            string saleDate = labelSaleDate.Text;
            decimal totalAmount = decimal.Parse(labelTotalAmount.Text);
            decimal tax = decimal.Parse(labelTax.Text);
            decimal discount = decimal.Parse(labelDiscount.Text);
            decimal deliveryFees = decimal.Parse(labelDeli.Text);
            decimal grandTotal = decimal.Parse(labelGTotal.Text);
            string userId = txtUserID.Text;

            // 2. Save data to the database
            try
            {
                // Replace with your actual connection string
                string connectionString = "YourConnectionStringHere";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "INSERT INTO Sales (SaleDate, TotalAmount, Tax, Discount, DeliveryFees, GrandTotal, UserID) " +
                                   "VALUES (@SaleDate, @TotalAmount, @Tax, @Discount, @DeliveryFees, @GrandTotal, @UserID)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@SaleDate", saleDate);
                        command.Parameters.AddWithValue("@TotalAmount", totalAmount);
                        command.Parameters.AddWithValue("@Tax", tax);
                        command.Parameters.AddWithValue("@Discount", discount);
                        command.Parameters.AddWithValue("@DeliveryFees", deliveryFees);
                        command.Parameters.AddWithValue("@GrandTotal", grandTotal);
                        command.Parameters.AddWithValue("@UserID", userId);

                        command.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Sale record saved successfully!");

                // 3. Open the Sale Detail Form
                frm_SaleDetail saleDetailForm = new frm_SaleDetail();
                saleDetailForm.Show();
                this.Close(); // Close the current form
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
