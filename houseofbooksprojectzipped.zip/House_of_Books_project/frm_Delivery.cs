﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace House_of_Books_project
{
    public partial class frm_Delivery : Form
    {
        public frm_Delivery()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string deliveryId = labelDeliID.Text;
            string saleId = labelSaleID.Text;
            string address = txtAdd.Text;
            string customerPhone = txtCusPh.Text;
            string deliveryDate = txtDeliDate.Text;

            
            try
            {
                
                string connectionString = "YourConnectionStringHere";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "INSERT INTO Deliveries (DeliveryID, SaleID, Address, CustomerPhone, DeliveryDate) " +
                                   "VALUES (@DeliveryID, @SaleID, @Address, @CustomerPhone, @DeliveryDate)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@DeliveryID", deliveryId);
                        command.Parameters.AddWithValue("@SaleID", saleId);
                        command.Parameters.AddWithValue("@Address", address);
                        command.Parameters.AddWithValue("@CustomerPhone", customerPhone);
                        command.Parameters.AddWithValue("@DeliveryDate", deliveryDate);

                        command.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Delivery details saved successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
