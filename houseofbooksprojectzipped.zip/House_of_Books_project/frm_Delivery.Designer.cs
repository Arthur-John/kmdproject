﻿namespace House_of_Books_project
{
    partial class frm_Delivery
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblDeliID = new System.Windows.Forms.Label();
            this.lblSaleID = new System.Windows.Forms.Label();
            this.lblAdd = new System.Windows.Forms.Label();
            this.lblCusPh = new System.Windows.Forms.Label();
            this.lblDeliDate = new System.Windows.Forms.Label();
            this.labelDeliID = new System.Windows.Forms.Label();
            this.labelSaleID = new System.Windows.Forms.Label();
            this.txtAdd = new System.Windows.Forms.TextBox();
            this.txtCusPh = new System.Windows.Forms.TextBox();
            this.txtDeliDate = new System.Windows.Forms.TextBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblDeliID
            // 
            this.lblDeliID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblDeliID.Location = new System.Drawing.Point(135, 57);
            this.lblDeliID.Name = "lblDeliID";
            this.lblDeliID.Size = new System.Drawing.Size(100, 23);
            this.lblDeliID.TabIndex = 0;
            this.lblDeliID.Text = "Delivery ID";
            // 
            // lblSaleID
            // 
            this.lblSaleID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSaleID.Location = new System.Drawing.Point(135, 148);
            this.lblSaleID.Name = "lblSaleID";
            this.lblSaleID.Size = new System.Drawing.Size(100, 23);
            this.lblSaleID.TabIndex = 1;
            this.lblSaleID.Text = "Sale ID";
            // 
            // lblAdd
            // 
            this.lblAdd.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblAdd.Location = new System.Drawing.Point(135, 257);
            this.lblAdd.Name = "lblAdd";
            this.lblAdd.Size = new System.Drawing.Size(100, 23);
            this.lblAdd.TabIndex = 2;
            this.lblAdd.Text = "Address";
            // 
            // lblCusPh
            // 
            this.lblCusPh.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCusPh.Location = new System.Drawing.Point(135, 356);
            this.lblCusPh.Name = "lblCusPh";
            this.lblCusPh.Size = new System.Drawing.Size(123, 27);
            this.lblCusPh.TabIndex = 3;
            this.lblCusPh.Text = "Customer Phone";
            // 
            // lblDeliDate
            // 
            this.lblDeliDate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblDeliDate.Location = new System.Drawing.Point(135, 444);
            this.lblDeliDate.Name = "lblDeliDate";
            this.lblDeliDate.Size = new System.Drawing.Size(100, 23);
            this.lblDeliDate.TabIndex = 4;
            this.lblDeliDate.Text = "Delivery Date";
            // 
            // labelDeliID
            // 
            this.labelDeliID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelDeliID.Location = new System.Drawing.Point(472, 57);
            this.labelDeliID.Name = "labelDeliID";
            this.labelDeliID.Size = new System.Drawing.Size(180, 23);
            this.labelDeliID.TabIndex = 5;
            // 
            // labelSaleID
            // 
            this.labelSaleID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelSaleID.Location = new System.Drawing.Point(472, 148);
            this.labelSaleID.Name = "labelSaleID";
            this.labelSaleID.Size = new System.Drawing.Size(180, 23);
            this.labelSaleID.TabIndex = 6;
            // 
            // txtAdd
            // 
            this.txtAdd.Location = new System.Drawing.Point(472, 255);
            this.txtAdd.Name = "txtAdd";
            this.txtAdd.Size = new System.Drawing.Size(180, 22);
            this.txtAdd.TabIndex = 7;
            // 
            // txtCusPh
            // 
            this.txtCusPh.Location = new System.Drawing.Point(472, 354);
            this.txtCusPh.Name = "txtCusPh";
            this.txtCusPh.Size = new System.Drawing.Size(180, 22);
            this.txtCusPh.TabIndex = 8;
            // 
            // txtDeliDate
            // 
            this.txtDeliDate.Location = new System.Drawing.Point(472, 442);
            this.txtDeliDate.Name = "txtDeliDate";
            this.txtDeliDate.Size = new System.Drawing.Size(180, 22);
            this.txtDeliDate.TabIndex = 9;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.Location = new System.Drawing.Point(444, 530);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(121, 40);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "&Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSave.Location = new System.Drawing.Point(225, 530);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(121, 40);
            this.btnSave.TabIndex = 11;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // frm_Delivery
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(910, 620);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.txtDeliDate);
            this.Controls.Add(this.txtCusPh);
            this.Controls.Add(this.txtAdd);
            this.Controls.Add(this.labelSaleID);
            this.Controls.Add(this.labelDeliID);
            this.Controls.Add(this.lblDeliDate);
            this.Controls.Add(this.lblCusPh);
            this.Controls.Add(this.lblAdd);
            this.Controls.Add(this.lblSaleID);
            this.Controls.Add(this.lblDeliID);
            this.Name = "frm_Delivery";
            this.Text = "frm_Delivery";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblDeliID;
        private System.Windows.Forms.Label lblSaleID;
        private System.Windows.Forms.Label lblAdd;
        private System.Windows.Forms.Label lblCusPh;
        private System.Windows.Forms.Label lblDeliDate;
        private System.Windows.Forms.Label labelDeliID;
        private System.Windows.Forms.Label labelSaleID;
        private System.Windows.Forms.TextBox txtAdd;
        private System.Windows.Forms.TextBox txtCusPh;
        private System.Windows.Forms.TextBox txtDeliDate;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSave;
    }
}