﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HouseofBooks.DBA;
//using HouseofBooks.Report;

namespace HouseofBooks.MasterData
{
    public partial class frm_BookList : Form
    {
        public frm_BookList()
        {
            InitializeComponent();
        }
        clsBooks obj_clsBooks = new clsBooks();
        clsMainDB obj_clsMainDB = new clsMainDB();
        string SPString = "";
        DataTable DT = new DataTable();

        private void ShowData()
        {
            SPString = string.Format("SP_Select_Books N'{0}',N'{1}',N'{2}'", "0", "0", "0");
            dgvBooks.DataSource = obj_clsMainDB.SelectData(SPString);

            dgvBooks.Columns[0].Width = (dgvBooks.Width / 100) * 10;
            dgvBooks.Columns[1].Visible = false;
            dgvBooks.Columns[2].Width = (dgvBooks.Width / 100) * 30;
            dgvBooks.Columns[3].Width = (dgvBooks.Width / 100) * 10;
            dgvBooks.Columns[4].Width = (dgvBooks.Width / 100) * 10;
            dgvBooks.Columns[5].Width = (dgvBooks.Width / 100) * 10;
            dgvBooks.Columns[6].Width = (dgvBooks.Width / 100) * 10;
            dgvBooks.Columns[7].Width = (dgvBooks.Width / 100) * 20;

            obj_clsMainDB.ToolStripTextBoxData(ref tstSearchWith, SPString, "Title");
            tslLabel.Text = "Title";

        }
        private void ShowEntry()
        {
            if (dgvBooks.CurrentRow.Cells[0].Value.ToString() == string.Empty)
            {
                MessageBox.Show("There is No Data");
            }
            else
            {
                frm_Books frm = new frm_Books();
                frm._BookID = Convert.ToInt32(dgvBooks.CurrentRow.Cells["BookID"].Value.ToString());
                frm.txtTitle.Text = dgvBooks.CurrentRow.Cells["Title"].Value.ToString();
                frm.txtCategory.Text = dgvBooks.CurrentRow.Cells["Category"].Value.ToString();
                frm.txtQty.Text= dgvBooks.CurrentRow.Cells["Qty"].Value.ToString();
                frm.txtPrice.Text = dgvBooks.CurrentRow.Cells["Price"].Value.ToString();
                frm.txtReleaseDate.Text = dgvBooks.CurrentRow.Cells["ReleaseDate"].Value.ToString();
                frm._isEdit = true;
                frm.ShowDialog();
                ShowData();


            }

        }

        private void frm_BookList_Load(object sender, EventArgs e)
        {
            ShowData();
        }

        private void tsbNew_Click(object sender, EventArgs e)
        {
            frm_Books frm = new frm_Books();
            frm.ShowDialog();
            ShowData();
        }

        private void dgvBooks_DoubleClick(object sender, EventArgs e)
        {
            ShowEntry();

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            ShowEntry();
        }

        private void tsbDelete_Click(object sender, EventArgs e)
        {
            string BookID = dgvBooks.CurrentRow.Cells["BookID"].Value.ToString();
            if (BookID == string.Empty)
            {
                MessageBox.Show("There is No Data");
            }
            else if (dgvBooks.CurrentRow.Cells["Qty"].Value.ToString() != "0")
            {
                MessageBox.Show("This has Qty and cannot be Deleted");
            }
            else
            {
                if(MessageBox.Show("Are you sure you want to delete?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    obj_clsBooks.BOOKID = Convert.ToInt32(BookID);
                    obj_clsBooks.ACTION = 2;
                    obj_clsBooks.SaveData();
                    MessageBox.Show("Successfully Delete");
                    ShowData();
                }
            }
        }

        private void tsmTitle_Click(object sender, EventArgs e)
        {
            tslLabel.Text = "Title";
            SPString = string.Format("SP_Select_Books N'{0}',N'{1}',N'{2}'", "0", "0", "0"); 
            obj_clsMainDB.ToolStripTextBoxData(ref tstSearchWith, SPString, "Title");
        }

        private void tsmCategory_Click(object sender, EventArgs e)
        {
            tslLabel.Text = "Category";
            SPString = string.Format("SP_Select_Books N'{0}',N'{1}',N'{2}'", "0", "0", "0");
            obj_clsMainDB.ToolStripTextBoxData(ref tstSearchWith, SPString, "Category");
        }

        private void tstSearchWith_TextChanged(object sender, EventArgs e)
        {
            if (tslLabel.Text == "Title")
            {
                SPString= string.Format("SP_Select_Books N'{0}',N'{1}',N'{2}'", tstSearchWith.Text.Trim().ToString(), "0", "2");
            }
            else if (tslLabel.Text == "Category")
            {
                SPString = string.Format("SP_Select_Books N'{0}',N'{1}',N'{2}'", tstSearchWith.Text.Trim().ToString(), "0", "3");
            }
            dgvBooks.DataSource = obj_clsMainDB.SelectData(SPString);
        }

        private void tsbPrint_Click(object sender, EventArgs e)
        {
            /*if (dgvBooks.Rows.Count > 1)
            {
                DataTable DT = new DataTable();
                DT = obj_clsMainDB.SelectData(SPString);
                frm_Report frmReport = new frm_Report();
                crpt_Books crpt = new crpt_Books();
                crpt.SetDataSource(DT);
                frmReport.crystalReportViewer1.ReportSource = crpt;
                frmReport.ShowDialog();
                ShowData();
            }
            else
            {
                MessageBox.Show("There is no Data");
            }*/
        }
    }
}
