﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HouseofBooks.DBA;


namespace HouseofBooks.MasterData
{
    public partial class frm_Books : Form
    {
        public frm_Books()
        {
            InitializeComponent();
        }
        clsBooks obj_clsBooks = new clsBooks();
        clsMainDB obj_clsMainDB = new clsMainDB();

        DataTable DT = new DataTable();
        public bool _isEdit = false;
        public int _BookID = 0;
        string SPString = "";

        private void frm_Books_Load(object sender, EventArgs e)
        {
            string Day = string.Format("{0:D2}", DateTime.Now.Day);
            string Month = string.Format("{0:D2}", DateTime.Now.Month);
            string Year = string.Format("{0:D2}", DateTime.Now.Year);
            lblUpdateDate.Text = Month + "/" + Day + "/" + Year;
            txtQty.Text = "0";
            txtPrice.Text = "0";
            txtTitle.Focus();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            int Ok;
            if (txtTitle.Text.Trim().ToString() == string.Empty)
            {
                MessageBox.Show("Please Type Title");
                txtTitle.Focus();
            }
            else if (txtCategory.Text.Trim().ToString() == string.Empty)
            {
                MessageBox.Show("Please Type Category");
                txtCategory.Focus();
            }
            else if (txtQty.Text.Trim().ToString() == string.Empty)
            {
                MessageBox.Show("Please Type Qty");
                txtQty.Focus();
            }
            else if (int.TryParse(txtQty.Text, out Ok) == false)
            {
                MessageBox.Show("Qty should be Number");
                txtQty.Focus();
                txtQty.SelectAll();
            }
            else if (Convert.ToInt32(txtQty.Text) < 0 || Convert.ToInt32(txtQty.Text) > 100)
            {
                MessageBox.Show("Qty should be Between 0 and 100");
                txtQty.Focus();
                txtQty.SelectAll();
            }
            else if (txtPrice.Text.Trim().ToString() == string.Empty)
            {
                MessageBox.Show("Please Type Price");
                txtPrice.Focus();
            }
            else if (int.TryParse(txtPrice.Text, out Ok) == false)
            {
                MessageBox.Show("Price should be Number");
                txtPrice.Focus();
                txtPrice.SelectAll();
            }
            else if (Convert.ToInt32(txtPrice.Text) != 0 && Convert.ToInt32(txtPrice.Text) < 1000 || Convert.ToInt32(txtPrice.Text) > 1000000)
            {
                MessageBox.Show("Price should be Between 1000 and 10Lakh or 0 price");
                txtPrice.Focus();
                txtPrice.SelectAll();
            }
            else if (txtReleaseDate.Text.Trim().ToString() == string.Empty)
            {
                MessageBox.Show("Please Type Release Year");
                txtReleaseDate.Focus();
            }
            else if (int.TryParse(txtReleaseDate.Text, out Ok) == false)
            {
                MessageBox.Show("ReleaseDate should be Number");
                txtReleaseDate.Focus();
                txtReleaseDate.SelectAll();
            }
            else if (Convert.ToInt32(txtReleaseDate.Text) != 0 && Convert.ToInt32(txtReleaseDate.Text) < 1000 || Convert.ToInt32(txtReleaseDate.Text) > DateTime.Now.Year)
            {
                MessageBox.Show("Please check Release Year");
                txtReleaseDate.Focus();
                txtReleaseDate.SelectAll();
            }
            else
            {
                SPString = string.Format("SP_Select_Books N'{0}',N'{1}',N'{2}'", txtTitle.Text.Trim().ToString(), "0", "1");
                DT = obj_clsMainDB.SelectData(SPString);
                if (DT.Rows.Count > 0 && _BookID != Convert.ToInt32(DT.Rows[0]["BookID"]))
                {
                    MessageBox.Show("This Book is Already Exist");
                    txtTitle.Focus();
                    txtTitle.SelectAll();
                }
                else
                {
                    obj_clsBooks.BOOKID = _BookID;
                    obj_clsBooks.TITLE = txtTitle.Text;
                    obj_clsBooks.CATEGORY = txtCategory.Text;
                    obj_clsBooks.QTY = Convert.ToInt32(txtQty.Text);
                    obj_clsBooks.PRICE = Convert.ToInt32(txtPrice.Text);
                    obj_clsBooks.RELEASEDATE = txtReleaseDate.Text;
                    obj_clsBooks.UPDATE = lblUpdateDate.Text;

                    if (_isEdit)
                    {
                        obj_clsBooks.ACTION = 1;
                        obj_clsBooks.SaveData();
                        MessageBox.Show("Successfully Edit", "Successfully", MessageBoxButtons.OK);
                        this.Close();
                    }
                    else
                    {
                        obj_clsBooks.ACTION = 0;
                        obj_clsBooks.SaveData();
                        MessageBox.Show("Successfully Save", "Successfully", MessageBoxButtons.OK);
                        this.Close();
                    }
                }

            }
        }
    }

}
