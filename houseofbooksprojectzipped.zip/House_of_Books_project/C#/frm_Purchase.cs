﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HouseofBooks.DBA;

namespace HouseofBooks.Purchase
{
    public partial class frm_Purchase : Form
    {
        public frm_Purchase()
        {
            InitializeComponent();
        }
        clsPurchase obj_clsPurchase = new clsPurchase();
        clsPurchaseDetail obj_clsPurchaseDetail = new clsPurchaseDetail();
        clsBooks obj_clsBooks = new clsBooks();
        clsMainDB obj_clsMainDB = new clsMainDB();

        DataTable DT = new DataTable();
        DataTable DTPurchase = new DataTable();
        int _PurchaseID = 0;
        string SPString = "";
        int count = 0;
        private void CreateTable()
        {
            DTPurchase.Rows.Clear();
            DTPurchase.Columns.Clear();
            DTPurchase.Columns.Add("BookID");
            DTPurchase.Columns.Add("Title");
            DTPurchase.Columns.Add("Qty");
            DTPurchase.Columns.Add("Price");
            DTPurchase.Columns.Add("Total");
            dgvPurchase.DataSource = DTPurchase;
        }
        public void ShowData()
        {
            SPString = string.Format("SP_Select_Supplier N'{0}',N'{1}',N'{2}'", "0", "0", "0");
            obj_clsMainDB.AddCombo(ref cboSupplier, SPString, "SupplierName", "SupplierID");

            SPString = string.Format("SP_Select_Books N'{0}',N'{1}',N'{2}'", "0", "0", "0");
            obj_clsMainDB.AddCombo(ref cboBooks, SPString, "Title", "BookID");

            SPString = string.Format("SP_Select_UserSetting N'{0}',N'{1}',N'{2}'", "0", "0", "0");
            obj_clsMainDB.AddCombo(ref cboStaff, SPString, "UserName", "UserID");
        }
        private void frm_Purchase_Load(object sender, EventArgs e)
        {
            CreateTable();
            ShowData();
        }

        private void cboBooks_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtPrice.Text = "";
            txtQty.Text = "";
            txtQty.Focus();
        }
        private void CalculateTotal()
        {
            int total = 0;
            if (DTPurchase.Rows.Count > 0)
            {
                foreach (DataRow Dr in DTPurchase.Rows)
                    total += Convert.ToInt32(Dr["Total"]);
            }
            lblTotalAmount.Text = total.ToString();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            int Ok = 0;
            if (Convert.ToInt32(cboBooks.SelectedValue.ToString()) == 0)
            {
                MessageBox.Show("Please choose Book");
                cboBooks.Focus();
            }
            else if (txtQty.Text.Trim().ToString() == string.Empty)
            {
                MessageBox.Show("Please Type Qty");
                txtQty.Focus();
            }
            else if (int.TryParse(txtQty.Text, out Ok) == false)
            {
                MessageBox.Show("Qty should be Number");
                txtQty.Focus();
                txtQty.SelectAll();
            }
            else if (Convert.ToInt32(txtQty.Text.Trim().ToString()) <= 0 || Convert.ToInt32(txtQty.Text.Trim().ToString()) > 100)
            {
                MessageBox.Show("Qty should be Between 1 and 100");
                txtQty.Focus();
                txtQty.SelectAll();
            }
            else if (txtPrice.Text.Trim().ToString() == string.Empty)
            {
                MessageBox.Show("Please Type Price");
                txtPrice.Focus();
            }
            else if (int.TryParse(txtPrice.Text, out Ok) == false)
            {
                MessageBox.Show("Price should be Number");
                txtPrice.Focus();
                txtPrice.SelectAll();
            }
            else if (Convert.ToInt32(txtPrice.Text.Trim().ToString()) < 1000 || Convert.ToInt32(txtPrice.Text.Trim().ToString()) > 1000000)
            {
                MessageBox.Show("Price should be Between 1000 and 10-Lakh ");
                txtPrice.Focus();
                txtPrice.SelectAll();
            }
            else
            {
                if (DTPurchase.Rows.Count > 0)
                {
                    DataRow[] Arr_Dr = DTPurchase.Select("BookID='" + cboBooks.SelectedValue.ToString() + "'");
                    count = Arr_Dr.Length;
                    if (count != 0)
                    {
                        MessageBox.Show("This is Already Exist");
                        return;
                    }
                }
                DataRow Dr = DTPurchase.NewRow();
                Dr["BookID"] = cboBooks.SelectedValue.ToString();
                Dr["Title"] = cboBooks.Text;
                Dr["Qty"] = txtQty.Text;
                Dr["Price"] = txtPrice.Text;
                Dr["Total"] = Convert.ToInt32(txtQty.Text) * Convert.ToInt32(txtPrice.Text);
                DTPurchase.Rows.Add(Dr);
                dgvPurchase.DataSource = DTPurchase;
                cboBooks.SelectedIndex = 0;
                CalculateTotal();
            }

        }
        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (DTPurchase.Rows.Count <= 0)
            {
                MessageBox.Show("There is no Data");
            }
            else if (dgvPurchase.CurrentRow.Cells["BookID"].Value.ToString() == string.Empty)
            {
                MessageBox.Show("There is no Data");
            }
            else
            {
                DataRow[] Arr_Dr = DTPurchase.Select("BookID='" + dgvPurchase.CurrentRow.Cells["BookID"].Value.ToString() + "'");
                DataRow Dr = Arr_Dr[0];
                Dr.Delete();
                dgvPurchase.DataSource = DTPurchase;
                CalculateTotal();
            }
        }

        private void dtbDate_ValueChanged(object sender, EventArgs e)
        {
            SPString = string.Format("SP_Select_Purchase N'{0}',N'{1}',N'{2}'", dtpDate.Text, "0", "2");
            DT = obj_clsMainDB.SelectData(SPString);
            int DateDiff = Convert.ToInt32(DT.Rows[0]["No"]);
            if (DateDiff > 0)
            {
                MessageBox.Show("Please check PurchaseDate");
                dtpDate.Text = DateTime.Now.ToShortDateString();
            }
            else if (DateDiff <= -10)
            {
                MessageBox.Show("Please check PurchaseDate");
                dtpDate.Text = DateTime.Now.ToShortDateString();
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (cboSupplier.SelectedValue.ToString() == "0")
            {
                MessageBox.Show("Please choose supplier ");
                cboSupplier.Focus();
            }
            else if (cboStaff.SelectedValue.ToString() == "0")
            {
                MessageBox.Show("Please choose staff ");
                cboStaff.Focus();
            }
            else if (DTPurchase.Rows.Count <= 0)
            {
                MessageBox.Show("There is no Data");
            }
            else
            {
                obj_clsPurchase.PDATE = dtpDate.Text;
                obj_clsPurchase.SID = Convert.ToInt32(cboSupplier.SelectedValue.ToString());
                obj_clsPurchase.TOTAMT = Convert.ToInt32(lblTotalAmount.Text);
                obj_clsPurchase.UID = Convert.ToInt32(cboStaff.SelectedValue.ToString());
                obj_clsPurchase.ACTION = 0;
                obj_clsPurchase.SaveData();

                SPString = string.Format("SP_Select_Purchase N'{0}',N'{1}',N'{2}'", "0", "0", "1");
                DT = obj_clsMainDB.SelectData(SPString);
                _PurchaseID = Convert.ToInt32(DT.Rows[0]["PurchaseID"].ToString());

                for (int i = 0; i < DTPurchase.Rows.Count; i++)
                {
                    obj_clsPurchaseDetail.PID = _PurchaseID;
                    obj_clsPurchaseDetail.BID = Convert.ToInt32(DTPurchase.Rows[i]["BookID"].ToString());
                    obj_clsPurchaseDetail.PQTY = Convert.ToInt32(DTPurchase.Rows[i]["Qty"].ToString());
                    obj_clsPurchaseDetail.PPRICE = Convert.ToInt32(DTPurchase.Rows[i]["Price"].ToString());
                    obj_clsPurchaseDetail.ACTION = 0;
                    obj_clsPurchaseDetail.SaveData();

                    obj_clsBooks.BOOKID = Convert.ToInt32(DTPurchase.Rows[i]["BookID"].ToString());
                    obj_clsBooks.QTY = Convert.ToInt32(DTPurchase.Rows[i]["Qty"].ToString());
                    obj_clsBooks.PRICE = Convert.ToInt32(DTPurchase.Rows[i]["Price"].ToString());
                    obj_clsBooks.ACTION = 3;
                    obj_clsBooks.SaveData();
                }
                MessageBox.Show("Successfully Save", "Successfully", MessageBoxButtons.OK);
                this.Close();
            }
        }
    }
}
