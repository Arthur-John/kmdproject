﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace House_of_Books_project
{
    public partial class frm_SaleDetail : Form
    {
        public frm_SaleDetail()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            string saleId = labelSaleID.Text;
            string bookId = labelBookID.Text;
            int saleQuantity = int.Parse(labelSaleQ.Text);
            decimal salePrice = decimal.Parse(labelSalePrice.Text);

            
            try
            {
                
                string connectionString = "YourConnectionStringHere";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "INSERT INTO SaleDetails (SaleID, BookID, SaleQuantity, SalePrice) " +
                                   "VALUES (@SaleID, @BookID, @SaleQuantity, @SalePrice)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@SaleID", saleId);
                        command.Parameters.AddWithValue("@BookID", bookId);
                        command.Parameters.AddWithValue("@SaleQuantity", saleQuantity);
                        command.Parameters.AddWithValue("@SalePrice", salePrice);

                        command.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Sale detail saved successfully!");

                
                var result = MessageBox.Show("Do you want delivery?", "Delivery Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    
                    frm_Delivery deliveryForm = new frm_Delivery();
                    deliveryForm.Show();
                    this.Close(); 
                }
                else
                {
                    ////// Redirect to the Sale Form//////
                    frm_Sale saleForm = new frm_Sale();
                    saleForm.Show();
                    this.Close(); 
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
